import { Injectable } from '@angular/core';
import { CartItem } from '../common/cart-item';
import { BehaviorSubject, Subject } from 'rxjs';
import { ThisReceiver } from '@angular/compiler';

@Injectable({
  providedIn: 'root'
})
export class CartService {
  cartItem: CartItem[] = []

  totalprice:Subject<number> = new BehaviorSubject<number>(0);
  totalQuantity: Subject<number> = new BehaviorSubject<number>(0);
  
  //local storage : data will be avalable even browser window is closed.
  storage: Storage = localStorage;

  //sessionStroage : data will be cleared once the browsee window is closed
 //storage: Storage = sessionStorage;


  constructor() {
    let data = JSON.parse(this.storage.getItem('cartItem'));
    if (data != null) {
      this.cartItem = data;
    }

    //compute totals based on the data that is read from stroage
    this.computeCartTotals();
  }
  
  //adding cartItems to the storage
  persistCartItems() {
    this.storage.setItem('cartItem', JSON.stringify(this.cartItem));
  }
  addToCart(theCartItem:CartItem){
    //check if we already have item in our cart
    let alreadyExistsInCart: boolean = false;
    let existingCartItem: CartItem | undefined;

    if(this.cartItem.length >0){
      existingCartItem = this.cartItem.find(
        (temCartItem) => temCartItem.id === theCartItem.id
      );

      // check if we foumd it
      alreadyExistsInCart = existingCartItem != undefined;
    }
    if(alreadyExistsInCart){
      // increament the quality
      alert('product Updated in cart')
      existingCartItem.quantity++;

    }else{
      // just add the item to cartItem array
      alert('new product added to cart')
      this.cartItem.push(theCartItem);
    }
// compute cart total and total quality
this.computeCartTotals();

  }
  computeCartTotals(){
    let totalpriceValue = 0;
    let totalQuantityValue = 0;

    for (let currentCartItem of this.cartItem ){
      totalpriceValue += currentCartItem.quantity * currentCartItem.unitPrice;
      totalQuantityValue += currentCartItem.quantity;
    }
      
     // publish new values
     this.totalprice.next(totalpriceValue) ;
    this.totalQuantity.next(totalQuantityValue);
    
    //persist cart data
    this.persistCartItems();
  }
  

  remove(theCartItem: CartItem) {
    //get index of item from cartItem array
    const itemIndex = this.cartItem.findIndex(
      (tempCartItem) => tempCartItem.id === theCartItem.id
    );

    //if found,remove the item
    if (itemIndex > -1) {
      this.cartItem.splice(itemIndex, 1);

      //update cart total and cart price
      this.computeCartTotals();
    }
  }
  decrementQuantity(theCartItem: CartItem) {
    theCartItem.quantity--;

    if (theCartItem.quantity === 0) {
      //remove the item from cart
      this.remove(theCartItem);
    } else {
      this.computeCartTotals();
    }
  }

  incrementQuantity(theCartItem: CartItem) {
    theCartItem.quantity++;
    this.computeCartTotals();
  }

  }